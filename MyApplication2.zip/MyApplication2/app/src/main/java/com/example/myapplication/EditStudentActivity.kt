package com.example.myapplication

import android.app.Activity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity

class EditStudentActivity : AppCompatActivity() {
    private lateinit var etName: EditText
    private lateinit var etMssv: EditText
    private lateinit var btnSave: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_student)

        etName = findViewById(R.id.etName)
        etMssv = findViewById(R.id.etMssv)
        btnSave = findViewById(R.id.btnSave)

        // Nhận dữ liệu từ Intent
        val name = intent.getStringExtra("name") ?: ""
        val mssv = intent.getStringExtra("mssv") ?: ""
        val position = intent.getIntExtra("position", -1)

        etName.setText(name)
        etMssv.setText(mssv)

        // Xử lý sự kiện lưu
        btnSave.setOnClickListener {
            val resultIntent = intent
            resultIntent.putExtra("name", etName.text.toString())
            resultIntent.putExtra("mssv", etMssv.text.toString())
            resultIntent.putExtra("position", position)
            setResult(Activity.RESULT_OK, resultIntent)
            finish()
        }
    }
}
