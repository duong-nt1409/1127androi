package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import android.view.ContextMenu
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.ListView
import androidx.appcompat.app.AppCompatActivity

data class Student(val name: String, val mssv: String)

class MainActivity : AppCompatActivity() {
    private lateinit var lvStudents: ListView
    private lateinit var studentList: MutableList<Student>
    private lateinit var adapter: ArrayAdapter<String>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        lvStudents = findViewById(R.id.lvStudents)
        studentList = mutableListOf()

        // Tạo adapter để hiển thị danh sách sinh viên
        adapter = ArrayAdapter(
            this,
            android.R.layout.simple_list_item_1,
            studentList.map { "${it.name} - ${it.mssv}" }
        )
        lvStudents.adapter = adapter

        // Đăng ký context menu cho ListView
        registerForContextMenu(lvStudents)

        // Xử lý sự kiện click vào một item trong danh sách
        lvStudents.setOnItemClickListener { _, _, position, _ ->
            openEditActivity(position)
        }
    }

    // Tạo Option Menu
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.menuAdd -> {
                // Mở activity thêm mới
                openEditActivity(-1)
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }

    // Tạo Context Menu
    override fun onCreateContextMenu(menu: ContextMenu?, v: View?, menuInfo: ContextMenu.ContextMenuInfo?) {
        super.onCreateContextMenu(menu, v, menuInfo)
        menuInflater.inflate(R.menu.context_menu, menu)
    }

    override fun onContextItemSelected(item: MenuItem): Boolean {
        val info = item.menuInfo as AdapterView.AdapterContextMenuInfo
        when (item.itemId) {
            R.id.menuEdit -> {
                openEditActivity(info.position)
                return true
            }
            R.id.menuRemove -> {
                studentList.removeAt(info.position)
                updateListView()
                return true
            }
        }
        return super.onContextItemSelected(item)
    }

    // Mở Activity Edit/Add
    private fun openEditActivity(position: Int) {
        val intent = Intent(this, EditStudentActivity::class.java)
        intent.putExtra("position", position)
        if (position >= 0) {
            intent.putExtra("name", studentList[position].name)
            intent.putExtra("mssv", studentList[position].mssv)
        }
        startActivityForResult(intent, 1)
    }

    // Nhận kết quả trả về từ EditStudentActivity
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1 && resultCode == RESULT_OK) {
            val name = data?.getStringExtra("name") ?: ""
            val mssv = data?.getStringExtra("mssv") ?: ""
            val position = data?.getIntExtra("position", -1) ?: -1

            if (position >= 0) {
                // Chỉnh sửa sinh viên
                studentList[position] = Student(name, mssv)
            } else {
                // Thêm mới sinh viên
                studentList.add(Student(name, mssv))
            }
            updateListView()
        }
    }

    private fun updateListView() {
        adapter.clear()
        adapter.addAll(studentList.map { "${it.name} - ${it.mssv}" })
        adapter.notifyDataSetChanged()
    }
}
